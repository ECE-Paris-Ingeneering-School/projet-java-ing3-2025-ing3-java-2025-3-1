package Dao;

// import des packages
import Modele.Client;
import java.sql.*;
import java.util.ArrayList;

/**
 * implémentation MySQL du stockage dans la base de données des méthodes définies dans l'interface
 * ClientDao.
 */
public class ClientDAOImpl implements ClientDAO {
    // attribut privé pour l'objet du DaoFactoru
    private DaoFactory daoFactory;

    // constructeur dépendant de la classe DaoFactory
    public ClientDAOImpl(DaoFactory daoFactory) {

        this.daoFactory = daoFactory;
    }

    @Override
    /**
     * Récupérer de la base de données tous les objets des clients dans une liste
     * @return : liste retournée des objets des clients récupérés
     */
    public ArrayList<Client> getAll() {
        ArrayList<Client> listeClients = new ArrayList<Client>();

        /*
            Récupérer la liste des clients de la base de données dans listeClients
        */
        try {
            // connexion
            Connection connexion = daoFactory.getConnection();;
            Statement statement = connexion.createStatement();

            // récupération des produits de la base de données avec la requete SELECT
            ResultSet resultats = statement.executeQuery("select * from clients");

            // 	Se déplacer sur le prochain enregistrement : retourne false si la fin est atteinte
            while (resultats.next()) {
                // récupérer les 3 champs de la table produits dans la base de données
                int clientId = resultats.getInt(1);
                String clientNom = resultats.getString(2);
                String clientMail = resultats.getString(3);

                // instancier un objet de Produit avec ces 3 champs en paramètres
                Client client = new Client(clientId,clientNom,clientMail);

                // ajouter ce produit à listeProduits
                listeClients.add(client);
            }
        }
        catch (SQLException e) {
            //traitement de l'exception
            e.printStackTrace();
            System.out.println("Création de la liste de clients impossible");
        }

        return listeClients;
    }

    @Override
    /**
     Ajouter un nouveau client en paramètre dans la base de données
     @params : client = objet de Client à insérer dans la base de données
     */
    public void ajouter(Client client){
        /*
            A COMPLETER
         */
        String sql = "INSERT INTO clients (clientNom, clientMail) VALUES (?, ?)";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {

            preparedStatement.setString(1, client.getclientNom());
            preparedStatement.setString(2, client.getclientMail());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Ajout du client impossible");
        }

    }

    /**
     * Permet de chercher et récupérer un objet de Client dans la base de données via son id en paramètre
     * @param : id
     * @return : objet de classe Client cherché et retourné
     */
    public Client chercher(int id)  {
        Client client = null;
        String sql = "SELECT * FROM clients WHERE clientID = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {

            // Affecter l'ID en paramètre de la requête
            preparedStatement.setInt(1, id);

            // Exécuter la requête
            try (ResultSet resultats = preparedStatement.executeQuery()) {
                // Si un enregistrement est trouvé
                if (resultats.next()) {
                    int clientId = resultats.getInt("clientID");
                    String clientNom = resultats.getString("clientNom");
                    String clientMail = resultats.getString("clientMail");

                    // Instancier l'objet Client
                    client = new Client(clientId, clientNom, clientMail);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erreur lors de la recherche du client.");
        }

        return client;

        /*
        Client client = null;
        String sql = "SELECT * FROM clients WHERE clientID = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {

            preparedStatement.setInt(1, id);
            ResultSet resultats = preparedStatement.executeQuery();

            if (resultats.next()) {
                client = new Client(resultats.getInt("clientID"),
                        resultats.getString("clientNom"),
                        resultats.getString("clientMail"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Client non trouvé dans la base de données");
        }

        return client;
         */
    }

    /**
     * Permet de modifier les données du nom de l'objet de la classe Client en paramètre
     * dans la base de données à partir de l'id de cet objet en paramètre
     * @param : client = objet en paramètre de la classe Client à mettre à jour à partir de son id
     * @return : objet client en paramètre mis à jour  dans la base de données à retourner
     */
    public Client modifier(Client client) {
        /*
            A COMPLETER
         */
        String sql = "UPDATE clients SET clientNom = ?, clientMail = ? WHERE clientID = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {

            preparedStatement.setString(1, client.getclientNom());
            preparedStatement.setString(2, client.getclientMail());
            preparedStatement.setInt(3, client.getClientId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Modification du client impossible");
        }

        return client;
    }

    @Override
    /**
     * Supprimer un objet de la classe Client en paramètre dans la base de données en respectant la contrainte
     * d'intégrité référentielle : en supprimant un client, supprimer aussi en cascade toutes les commandes de la
     * table commander qui ont l'id du client supprimé.
     * @params : client = objet de Client en paramètre à supprimer de la base de données
     */
    public void supprimer (Client client) {
        /*
            A COMPLETER
         */
        String sql = "DELETE FROM clients WHERE clientID = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {

            preparedStatement.setInt(1, client.getClientId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Suppression du client impossible");
        }

    }
}


