package Vue;

// import des packages
import Modele.Produit;
import java.util.ArrayList;
import Dao.*;

public class VueProduit {
    /**
     * Méthode qui affiche un produit
     * @param product = objet d'un produit
     */
    public void afficherProduit(Produit product) {
        if (product != null) {
            System.out.println("Id produit : " + product.getProduitId() +
                    " Nom : " + product.getProduitNom() +
                    " prix = " + product.getProduitPrix());
        } else {
            System.out.println("Produit invalide.");
        }
    }

    public void afficherProduit(Produit product) {
        // Afficher un produit
        System.out.println("Id produit : " + product.getProduitId() + " Nom : " + product.getProduitNom()
                           + " prix = " + product.getProduitPrix());
    }

    /**
     * Méthode qui affiche la liste des produits
     * @param produits = liste des produits
     */
    public void afficherListeProduits(ArrayList<Produit> produits) {
        if (produits == null || produits.isEmpty()) {
            System.out.println("Aucun produit à afficher.");
        } else {
        // Afficher la liste des produits
        for (Produit product : produits) {
            afficherProduit(product);
        }
    }
}
