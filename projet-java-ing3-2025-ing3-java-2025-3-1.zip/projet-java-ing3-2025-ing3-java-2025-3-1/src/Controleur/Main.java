package Controleur;

// import des packages
import java.sql.*;
import Dao.*;
import Modele.*;
import Vue.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Déclaration et instanciation des objets des classes DaoFactory, ProduitDAOImpl, VueProduit,
        // ClientDAOImpl, VueClient, CommanderDAOImpl et VueCommander
        DaoFactory dao = DaoFactory.getInstance("shopping_db", "root", "");
        ProduitDAOImpl prodao = new ProduitDAOImpl(dao);
        VueProduit vuepro = new VueProduit();
        ClientDAOImpl clidao = new ClientDAOImpl(dao);
        VueClient vuecli = new VueClient();
        CommanderDAOImpl comdao = new CommanderDAOImpl(dao);
        VueCommander vuecom = new VueCommander();

        // Récupérer la liste des produits de la base de données avec l'objet prodao de la classe ProduitDAOImpl
        ArrayList<Produit> produits = prodao.getAll();

        // Afficher la liste des produits récupérés avec l'objet vuepro de la classe VueProduit
        vuepro.afficherListeProduits(produits);

        // Récupérer la liste des clients de la base de données avec l'objet clidao de la classe ClientDAOImpl
        ArrayList<Client> clients = clidao.getAll();

        // Afficher la liste des clients récupérés avec l'objet vuecli de la classe VueClient
        vuecli.afficherListeClients(clients);

        // Récupérer la liste des commandes de la base de données avec l'objet comdao de la classe CommanderDAOImpl
        ArrayList<Commander> achats = comdao.getAll();

        // Afficher la liste des commandes récupérées avec l'objet vuecom de la classe VueCommander
        vuecom.afficherListeCommandes(achats, dao);

        /*
            A COMPLETER :

            1) Compléter toutes les méthodes de la classe ProduitDAOImpl avec la mention A COMPLETER.
            2) Saisir un nom de produit (String) et son prix (double).
            3) Instancier un objet de Produit avec ce nom et ce prix.
            4) Ajouter cet objet dans la table produits de la base de données : en appelant la méthode ajouter de
               l'objet prodao (voir plus haut) de la classe ProduitDAOImpl avec en paramètre l'objet instancié du
               Produit à l'étape 3).
            5) Saisir un identifiant (int) de produit.
            6) Dans la table produits de la base de données, chercher un produit avec l'identifiant saisi. Appeler la
               méthode chercher de l'objet prodao (voir plus haut) de la classe ProduitDAOImpl, avec l'identifiant saisi
               en paramètre. Puis récupérer l'objet de la classe Produit. Si cet objet est null (vide), afficher que
               l'identifiant de ce produit n'est pas la table produits. Sinon appeler la méthode afficherProduit de
               l'objet vuepro (voir plus haut) de la classe VueProduit, avec l'objet du Produit récupéré en paramètre.
            7) Modifier un produit dans la base de données : à partir de l'objet instancié de Produit à l'étape 3),
               modifier son prix (comme vous voulez), en appelant la méthode modifier de l'objet prodao (voir plus haut)
               de la classe ProduitDAOImpl, avec en paramètre l'objet du Produit. Récupérer cet objet de Produit après
               l'appel de cette méthode modifier. Puis appeler la méthode afficherProduit de l'objet vuepro (voir plus haut)
               de la classe VueProduit, avec en paramètre l'objet de Produit récupéré.
            8) Supprimer un produit de la base de données : à partir de l'objet prodao (voir plus haut) de la classe
               ProduitDAOImpl, appeler la méthode supprimer de cet objet, avec en paramètre l'objet instancié de
               Produit à l'étape 4).
            9) Compléter toutes les méthodes de la classe ClientDAOImpl avec la mention A COMPLETER.
            10) Reprendre les mêmes instructions des étapes 2) à 9) pour les objets et méthodes des classes
                ClientDAOImpl (voir objet clidao plus haut), VueClient (voir objet vuecli plus haut) et Client avec la
                table clients de la base de données.
            11) Compléter toutes les méthodes de la classe CommanderDAOImpl avec la mention A COMPLETER.
            12) Reprendre les mêmes instructions des étapes 2) à 9) pour les objets et méthodes des classes
                CommanderDAOImpl (voir objet comdao plus haut), VueClient (voir objet vuecom plus haut) et Commander
                avec la table commander de la base de données.
         */

        // Fermer ma connexion
        dao.disconnect();
    }
}